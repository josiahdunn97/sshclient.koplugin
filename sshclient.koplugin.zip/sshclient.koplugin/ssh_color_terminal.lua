-- Dedicated ANSI colour SSH terminal for sshclient.koplugin.
-- Own PTY, screen model, SGR colour renderer and docked SSH keyboard. Does not use
-- KOReader's Terminal emulator or global virtual keyboard for SSH text entry.

local ffi = require("ffi")
local bit = require("bit")
require("ffi/posix_h")
-- A private structure name avoids conflicts with the POSIX bundle shipped by
-- different KOReader builds. TIOCSWINSZ is the Linux ioctl value (0x5414).
pcall(ffi.cdef, [[
    struct sshclient_winsize {
        unsigned short ws_row;
        unsigned short ws_col;
        unsigned short ws_xpixel;
        unsigned short ws_ypixel;
    };
]])
pcall(ffi.cdef, [[int ioctl(int fd, unsigned long request, ...);]])

local C = ffi.C
local Device = require("device")
local Blitbuffer = require("ffi/blitbuffer")
local Font = require("ui/font")
local TextWidget = require("ui/widget/textwidget")
local TextViewer = require("ui/widget/textviewer")
local Geom = require("ui/geometry")
local InfoMessage = require("ui/widget/infomessage")
local UIManager = require("ui/uimanager")
local _ = require("gettext")
local Screen = Device.screen

-- Match Zen OS' responsive keyboard behavior: permit fast consecutive touch
-- taps and avoid forcing a full refresh between virtual-key callbacks. These
-- hooks are installed once and are active only for windows that opt in.
local function enableConcurrentTapSupport()
    local input = Device.input
    if not input then return end

    if not UIManager._zen_concurrent_taps and not UIManager._sshclient_concurrent_taps then
        UIManager._sshclient_concurrent_taps = true
        local original_show = UIManager.show
        local original_close = UIManager.close
        UIManager.show = function(manager, widget, ...)
            original_show(manager, widget, ...)
            if widget and (not manager.silent_mode or not widget.honor_silent_mode) then
                if Device.input then
                    Device.input.allow_concurrent_taps = widget.allow_concurrent_taps == true
                end
            end
        end
        UIManager.close = function(manager, widget, ...)
            original_close(manager, widget, ...)
            local top_window = manager._window_stack[#manager._window_stack]
            if Device.input then
                Device.input.allow_concurrent_taps = top_window
                    and top_window.widget.allow_concurrent_taps == true or false
            end
        end
    end

    -- Backport the same second-contact tap handling used by Zen OS where the
    -- installed KOReader does not already have it.
    local ok, GestureDetector = pcall(require, "device/gesturedetector")
    if not ok or not GestureDetector or not debug or not debug.getupvalue then return end
    local Contact
    for index = 1, 64 do
        local name, value = debug.getupvalue(GestureDetector.newContact, index)
        if not name then break end
        if name == "Contact" then Contact = value; break end
    end
    if type(Contact) ~= "table" or Contact._sshclient_concurrent_taps then return end
    Contact._sshclient_concurrent_taps = true
    local original_tap_state = Contact.tapState
    Contact.tapState = function(contact, new_tap)
        local tev = contact.current_tev
        if tev and tev.id == -1 and contact.buddy_contact and contact.down
                and contact.ges_dec and contact.ges_dec.input
                and contact.ges_dec.input.allow_concurrent_taps then
            contact.ges_dec:dropContact(contact)
            return {
                ges = "tap",
                pos = Geom:new{ x = tev.x, y = tev.y, w = 0, h = 0 },
                time = tev.timev,
            }
        end
        return original_tap_state(contact, new_tap)
    end
end

local ColorTerminal = {}
local Session = {}
Session.__index = Session
local getTerminalSize

local MAX_SCROLLBACK = 300
-- Input is immediate; screen rendering is deliberately coalesced to avoid
-- repeated e-ink/color-panel redraws while programs such as htop are busy.
local POLL_INTERVAL = 0.05
local RENDER_INTERVAL = 0.12

local function nightMode()
    -- The framebuffer is the source of truth for whether KOReader is actually
    -- in night mode. The saved setting may briefly disagree while KOReader is
    -- switching modes (or in custom/no-framework flows).
    if Screen and type(Screen.night_mode) == "boolean" then
        return Screen.night_mode
    end
    local ok, value = pcall(function()
        return G_reader_settings and G_reader_settings:isTrue("night_mode")
    end)
    return ok and value == true
end

-- These are the colors we want the user to SEE after KOReader's global
-- night-mode framebuffer inversion. Keep the terminal's logical color model
-- in final/display colors; renderColor() compensates only at HTML-render time.
local function themeColors()
    if nightMode() then
        return "#f4f4f4", "#000000"
    end
    return "#101010", "#ffffff"
end

-- KOReader night mode inverts the final framebuffer. HTML/MuPDF content with
-- explicit CSS colors is inverted too, so pre-invert every terminal color to
-- preserve intended ANSI hues and a black terminal background on screen.
local function renderColor(color)
    if not nightMode() or type(color) ~= "string" then return color end
    local r, g, b = color:match("^#(%x%x)(%x%x)(%x%x)$")
    if not r then return color end
    return string.format("#%02x%02x%02x", 255 - tonumber(r, 16),
        255 - tonumber(g, 16), 255 - tonumber(b, 16))
end

local DEFAULT_FG, DEFAULT_BG = themeColors()

local function ansiPalette()
    if nightMode() then
        return {
            "#000000", "#e51c23", "#00a83b", "#c7a600",
            "#1769aa", "#c2188b", "#008fa3", "#d9d9d9",
            "#5c5c5c", "#ff5252", "#35c759", "#ffd740",
            "#4da3ff", "#ff5ac8", "#22d3ee", "#ffffff",
        }
    end
    return {
        "#000000", "#b00020", "#006b2b", "#806600",
        "#0057a8", "#8a0066", "#006f80", "#202020",
        "#666666", "#d00000", "#008a35", "#8a7000",
        "#005fcc", "#b0008f", "#007f99", "#000000",
    }
end
local ANSI16 = ansiPalette()

local function clamp(value, low, high)
    return math.max(low, math.min(high, value))
end

local function html_escape(value)
    return tostring(value or ""):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;")
end

local function color_hex(r, g, b)
    return string.format("#%02x%02x%02x", clamp(tonumber(r) or 0, 0, 255),
        clamp(tonumber(g) or 0, 0, 255), clamp(tonumber(b) or 0, 0, 255))
end

local function ansi256(n)
    n = clamp(tonumber(n) or 0, 0, 255)
    if n < 16 then return ANSI16[n + 1] end
    if n < 232 then
        local idx = n - 16
        local r = math.floor(idx / 36)
        local g = math.floor((idx % 36) / 6)
        local b = idx % 6
        local function cube(v) return v == 0 and 0 or 55 + v * 40 end
        return color_hex(cube(r), cube(g), cube(b))
    end
    local gray = 8 + (n - 232) * 10
    return color_hex(gray, gray, gray)
end

local function new_cell(fg, bg)
    return { ch = " ", fg = fg or DEFAULT_FG, bg = bg or DEFAULT_BG,
        fg_source = "default", bg_source = "default",
        bold = false, underline = false, inverse = false }
end

local function copy_row(row)
    local copy = {}
    for i, cell in ipairs(row) do
        copy[i] = {
            ch = cell.ch, fg = cell.fg, bg = cell.bg,
            fg_source = cell.fg_source, bg_source = cell.bg_source,
            fg_palette_index = cell.fg_palette_index, bg_palette_index = cell.bg_palette_index,
            bold = cell.bold, underline = cell.underline, inverse = cell.inverse,
        }
    end
    return copy
end

-- SSH input is handled by the compact keyboard docked below the terminal output.

function Session:updateTheme()
    local fg, bg = themeColors()
    local active_night = nightMode()
    local old_fg, old_bg = self.theme_fg, self.theme_bg
    local old_palette = ANSI16
    if fg == old_fg and bg == old_bg and active_night == self.theme_night then return false end

    local new_palette = ansiPalette()
    local function remap(color, source, palette_index, old_default, new_default)
        if source == "default" then return new_default end
        if source == "ansi" and palette_index ~= nil then
            return new_palette[palette_index + 1] or color
        end
        -- Fallback for cells created before explicit color-source metadata was
        -- available (for example after a plugin hot reload).
        if source == nil and color == old_default then return new_default end
        if source == nil then
            for index, old_color in ipairs(old_palette) do
                if color == old_color then return new_palette[index] or color end
            end
        end
        -- Truecolor and the extended 6x6x6/gray ANSI palette stay unchanged.
        return color
    end

    local function retheme_rows(rows)
        for _, row in ipairs(rows or {}) do
            for _, cell in ipairs(row) do
                cell.fg = remap(cell.fg, cell.fg_source, cell.fg_palette_index, old_fg, fg)
                cell.bg = remap(cell.bg, cell.bg_source, cell.bg_palette_index, old_bg, bg)
            end
        end
    end
    retheme_rows(self.grid)
    retheme_rows(self.history)
    retheme_rows(self.saved_screen)

    self.fg = remap(self.fg, self.fg_source, self.fg_palette_index, old_fg, fg)
    self.bg = remap(self.bg, self.bg_source, self.bg_palette_index, old_bg, bg)
    if self.saved_cursor then
        self.saved_cursor.fg = remap(self.saved_cursor.fg, self.saved_cursor.fg_source,
            self.saved_cursor.fg_palette_index, old_fg, fg)
        self.saved_cursor.bg = remap(self.saved_cursor.bg, self.saved_cursor.bg_source,
            self.saved_cursor.bg_palette_index, old_bg, bg)
    end

    self.theme_fg, self.theme_bg = fg, bg
    self.theme_night = active_night
    DEFAULT_FG, DEFAULT_BG = fg, bg
    ANSI16 = new_palette
    return true
end

function Session:newGrid()
    local grid = {}
    for y = 1, self.rows do
        local row = {}
        for x = 1, self.cols do row[x] = new_cell() end
        grid[y] = row
    end
    return grid
end

function Session:resetScreen()
    self.fg = DEFAULT_FG
    self.bg = DEFAULT_BG
    self.fg_source, self.bg_source = "default", "default"
    self.fg_palette_index, self.bg_palette_index = nil, nil
    self.bold = false
    self.underline = false
    self.inverse = false
    self.wrap = true
    self.x, self.y = 1, 1
    self.wrap_pending = false
    self.scroll_top, self.scroll_bottom = 1, self.rows
    self.cursor_visible = true
    self.grid = self:newGrid()
    self.saved_cursor = nil
    self.saved_screen = nil
end

function Session:blankCell()
    return {
        ch = " ", fg = self.fg, bg = self.bg,
        fg_source = self.fg_source, bg_source = self.bg_source,
        fg_palette_index = self.fg_palette_index, bg_palette_index = self.bg_palette_index,
        bold = self.bold, underline = self.underline, inverse = self.inverse,
    }
end

function Session:blankRow()
    local row = {}
    for x = 1, self.cols do row[x] = self:blankCell() end
    return row
end

function Session:resizeScreen(cols, rows)
    rows = clamp(rows or self.rows, 8, 100)
    cols = clamp(cols or self.cols, 60, 160)
    local old_rows, old_cols = self.rows, self.cols
    if rows < old_rows then
        -- Keep the TOP of the live terminal when the docked keyboard opens.
        -- Retaining the bottom rows made ordinary output disappear (it is
        -- followed by blank rows), and reduced htop to its final visible line.
        -- The foreground app receives SIGWINCH from TIOCSWINSZ and can redraw
        -- its full-screen interface using the new dimensions.
        local new_grid = {}
        for y = 1, rows do
            local old = self.grid[y] or {}
            local row = {}
            for x = 1, cols do
                local cell = old[x] or new_cell(DEFAULT_FG, DEFAULT_BG)
                row[x] = { ch = cell.ch, fg = cell.fg, bg = cell.bg,
                    fg_source = cell.fg_source, bg_source = cell.bg_source,
                    fg_palette_index = cell.fg_palette_index, bg_palette_index = cell.bg_palette_index,
                    bold = cell.bold, underline = cell.underline, inverse = cell.inverse }
            end
            new_grid[y] = row
        end
        self.grid = new_grid
        self.y = clamp(self.y, 1, rows)
    else
        for y = old_rows + 1, rows do
            local row = {}
            for x = 1, cols do row[x] = new_cell(DEFAULT_FG, DEFAULT_BG) end
            self.grid[y] = row
        end
    end
    if cols ~= old_cols then
        for y = 1, rows do
            local old = self.grid[y] or {}
            local row = {}
            for x = 1, cols do
                local cell = old[x] or new_cell(DEFAULT_FG, DEFAULT_BG)
                row[x] = { ch = cell.ch, fg = cell.fg, bg = cell.bg,
                    fg_source = cell.fg_source, bg_source = cell.bg_source,
                    fg_palette_index = cell.fg_palette_index, bg_palette_index = cell.bg_palette_index,
                    bold = cell.bold, underline = cell.underline, inverse = cell.inverse }
            end
            self.grid[y] = row
        end
    end
    -- TUIs such as htop use the alternate screen. Resize that saved screen as
    -- well, or leaving htop could restore a grid with the old row count.
    if self.saved_screen then
        local saved, resized = self.saved_screen, {}
        -- Keep the same top-left region for the alternate screen too.
        for y = 1, math.min(rows, old_rows) do
            local old = saved[y] or {}
            local row = {}
            for x = 1, cols do
                local cell = old[x] or new_cell(DEFAULT_FG, DEFAULT_BG)
                row[x] = { ch = cell.ch, fg = cell.fg, bg = cell.bg,
                    fg_source = cell.fg_source, bg_source = cell.bg_source,
                    fg_palette_index = cell.fg_palette_index, bg_palette_index = cell.bg_palette_index,
                    bold = cell.bold, underline = cell.underline, inverse = cell.inverse }
            end
            resized[y] = row
        end
        for y = #resized + 1, rows do
            local row = {}
            for x = 1, cols do row[x] = new_cell(DEFAULT_FG, DEFAULT_BG) end
            resized[y] = row
        end
        self.saved_screen = resized
    end
    if self.saved_cursor then
        self.saved_cursor.x = clamp(self.saved_cursor.x or 1, 1, cols)
        self.saved_cursor.y = clamp(self.saved_cursor.y or 1, 1, rows)
    end
    self.rows, self.cols = rows, cols
    self.x = clamp(self.x, 1, cols)
    self.y = clamp(self.y, 1, rows)
    self.scroll_top, self.scroll_bottom = 1, rows
    self.wrap_pending = false
    if self.master then
        pcall(function()
            local ws = ffi.new("struct sshclient_winsize[1]")
            ws[0].ws_row = rows
            ws[0].ws_col = cols
            ws[0].ws_xpixel = 0
            ws[0].ws_ypixel = 0
            C.ioctl(self.master, 0x5414, ws)
        end)
    end
end

function Session:saveHistory(row)
    self.history[#self.history + 1] = copy_row(row)
    if #self.history > MAX_SCROLLBACK then table.remove(self.history, 1) end
end

function Session:scrollUp(top, bottom, count)
    top, bottom = top or self.scroll_top, bottom or self.scroll_bottom
    count = clamp(count or 1, 1, self.rows)
    for _ = 1, count do
        if top == 1 and bottom == self.rows then self:saveHistory(self.grid[top]) end
        table.remove(self.grid, top)
        table.insert(self.grid, bottom, self:blankRow())
    end
end

function Session:scrollDown(top, bottom, count)
    top, bottom = top or self.scroll_top, bottom or self.scroll_bottom
    count = clamp(count or 1, 1, self.rows)
    for _ = 1, count do
        table.remove(self.grid, bottom)
        table.insert(self.grid, top, self:blankRow())
    end
end

function Session:lineFeed()
    if self.y == self.scroll_bottom then
        self:scrollUp(self.scroll_top, self.scroll_bottom, 1)
    else
        self.y = math.min(self.rows, self.y + 1)
    end
end

function Session:reverseIndex()
    if self.y == self.scroll_top then
        self:scrollDown(self.scroll_top, self.scroll_bottom, 1)
    else
        self.y = math.max(1, self.y - 1)
    end
end

function Session:putChar(ch)
    if self.wrap_pending then
        if self.wrap then
            self.x = 1
            self:lineFeed()
        end
        self.wrap_pending = false
    end
    if self.x < 1 then self.x = 1 end
    if self.x > self.cols then self.x = self.cols end
    self.grid[self.y][self.x] = {
        ch = ch, fg = self.fg, bg = self.bg,
        fg_source = self.fg_source, bg_source = self.bg_source,
        fg_palette_index = self.fg_palette_index, bg_palette_index = self.bg_palette_index,
        bold = self.bold, underline = self.underline, inverse = self.inverse,
    }
    if self.x >= self.cols then
        self.wrap_pending = true
    else
        self.x = self.x + 1
    end
end

function Session:eraseLine(mode)
    local row = self.grid[self.y]
    local from_x, to_x = self.x, self.cols
    if mode == 1 then from_x, to_x = 1, self.x
    elseif mode == 2 then from_x, to_x = 1, self.cols end
    for x = from_x, to_x do row[x] = self:blankCell() end
end

function Session:eraseDisplay(mode)
    if mode == 2 or mode == 3 then
        for y = 1, self.rows do self.grid[y] = self:blankRow() end
        self.x, self.y, self.wrap_pending = 1, 1, false
        return
    end
    if mode == 0 then
        self:eraseLine(0)
        for y = self.y + 1, self.rows do self.grid[y] = self:blankRow() end
    elseif mode == 1 then
        for y = 1, self.y - 1 do self.grid[y] = self:blankRow() end
        self:eraseLine(1)
    end
end

function Session:setSGR(params)
    if #params == 0 then params = { 0 } end
    local i = 1
    while i <= #params do
        local n = params[i] or 0
        if n == 0 then
            self.fg, self.bg = DEFAULT_FG, DEFAULT_BG
            self.fg_source, self.bg_source = "default", "default"
            self.fg_palette_index, self.bg_palette_index = nil, nil
            self.bold, self.underline, self.inverse = false, false, false
        elseif n == 1 then self.bold = true
        elseif n == 2 then self.bold = false
        elseif n == 4 then self.underline = true
        elseif n == 7 then self.inverse = true
        elseif n == 22 then self.bold = false
        elseif n == 24 then self.underline = false
        elseif n == 27 then self.inverse = false
        elseif n >= 30 and n <= 37 then
            self.fg_palette_index = n - 30
            self.fg_source, self.fg = "ansi", ANSI16[self.fg_palette_index + 1]
        elseif n == 39 then
            self.fg, self.fg_source, self.fg_palette_index = DEFAULT_FG, "default", nil
        elseif n >= 40 and n <= 47 then
            self.bg_palette_index = n - 40
            self.bg_source, self.bg = "ansi", ANSI16[self.bg_palette_index + 1]
        elseif n == 49 then
            self.bg, self.bg_source, self.bg_palette_index = DEFAULT_BG, "default", nil
        elseif n >= 90 and n <= 97 then
            self.fg_palette_index = n - 90 + 8
            self.fg_source, self.fg = "ansi", ANSI16[self.fg_palette_index + 1]
        elseif n >= 100 and n <= 107 then
            self.bg_palette_index = n - 100 + 8
            self.bg_source, self.bg = "ansi", ANSI16[self.bg_palette_index + 1]
        elseif n == 38 or n == 48 then
            local is_fg = n == 38
            local mode = params[i + 1]
            local color, palette_index, source
            if mode == 5 and params[i + 2] ~= nil then
                local index = clamp(params[i + 2], 0, 255)
                color = ansi256(index)
                if index < 16 then
                    palette_index, source = index, "ansi"
                else
                    source = "rgb"
                end
                i = i + 2
            elseif mode == 2 and params[i + 4] ~= nil then
                color = color_hex(params[i + 2], params[i + 3], params[i + 4])
                source = "rgb"
                i = i + 4
            end
            if color then
                if is_fg then
                    self.fg, self.fg_source, self.fg_palette_index = color, source, palette_index
                else
                    self.bg, self.bg_source, self.bg_palette_index = color, source, palette_index
                end
            end
        end
        i = i + 1
    end
end

function Session:parseParams(value)
    local private = value:match("^([?<=>!]+)") or ""
    value = value:gsub("^[?<=>!]+", "")
    local out = {}
    if value == "" then return out, private end
    for part in (value .. ";"):gmatch("(.-);") do
        out[#out + 1] = tonumber(part:match("^%d+")) or 0
    end
    return out, private
end

function Session:handleCSI(raw, final)
    local p, private = self:parseParams(raw)
    local a = p[1] or 0
    local b = p[2] or 0
    local function amount(v) return v == 0 and 1 or v end
    if final == "A" then self.y = math.max(self.scroll_top, self.y - amount(a)); self.wrap_pending = false
    elseif final == "B" then self.y = math.min(self.scroll_bottom, self.y + amount(a)); self.wrap_pending = false
    elseif final == "C" then self.x = math.min(self.cols, self.x + amount(a)); self.wrap_pending = false
    elseif final == "D" then self.x = math.max(1, self.x - amount(a)); self.wrap_pending = false
    elseif final == "E" then self.y = math.min(self.scroll_bottom, self.y + amount(a)); self.x = 1; self.wrap_pending = false
    elseif final == "F" then self.y = math.max(self.scroll_top, self.y - amount(a)); self.x = 1; self.wrap_pending = false
    elseif final == "G" or final == "`" then self.x = clamp(amount(a), 1, self.cols); self.wrap_pending = false
    elseif final == "d" then self.y = clamp(amount(a), 1, self.rows); self.wrap_pending = false
    elseif final == "H" or final == "f" then
        self.y = clamp(amount(a), 1, self.rows)
        self.x = clamp(amount(b), 1, self.cols)
        self.wrap_pending = false
    elseif final == "J" then self:eraseDisplay(a)
    elseif final == "K" then self:eraseLine(a)
    elseif final == "m" then self:setSGR(p)
    elseif final == "s" then self.saved_cursor = { x = self.x, y = self.y, fg = self.fg, bg = self.bg,
        fg_source = self.fg_source, bg_source = self.bg_source,
        fg_palette_index = self.fg_palette_index, bg_palette_index = self.bg_palette_index,
        bold = self.bold, underline = self.underline, inverse = self.inverse }
    elseif final == "u" and self.saved_cursor then
        local s = self.saved_cursor
        self.x, self.y, self.fg, self.bg = s.x, s.y, s.fg, s.bg
        self.fg_source, self.bg_source = s.fg_source, s.bg_source
        self.fg_palette_index, self.bg_palette_index = s.fg_palette_index, s.bg_palette_index
        self.bold, self.underline, self.inverse = s.bold, s.underline, s.inverse
    elseif final == "r" then
        local top = p[1] or 1
        local bottom = p[2] or self.rows
        if top < bottom and top >= 1 and bottom <= self.rows then
            self.scroll_top, self.scroll_bottom = top, bottom
        else
            self.scroll_top, self.scroll_bottom = 1, self.rows
        end
        self.x, self.y, self.wrap_pending = 1, 1, false
    elseif final == "S" then self:scrollUp(self.scroll_top, self.scroll_bottom, amount(a))
    elseif final == "T" then self:scrollDown(self.scroll_top, self.scroll_bottom, amount(a))
    elseif final == "L" then
        if self.y >= self.scroll_top and self.y <= self.scroll_bottom then self:scrollDown(self.y, self.scroll_bottom, amount(a)) end
    elseif final == "M" then
        if self.y >= self.scroll_top and self.y <= self.scroll_bottom then self:scrollUp(self.y, self.scroll_bottom, amount(a)) end
    elseif final == "@" then
        local row = self.grid[self.y]
        for _ = 1, amount(a) do
            table.insert(row, self.x, self:blankCell())
            table.remove(row, self.cols + 1)
        end
    elseif final == "P" then
        local row = self.grid[self.y]
        for _ = 1, amount(a) do
            table.remove(row, self.x)
            row[self.cols] = self:blankCell()
        end
    elseif final == "X" then
        local row = self.grid[self.y]
        for x = self.x, math.min(self.cols, self.x + amount(a) - 1) do row[x] = self:blankCell() end
    elseif final == "h" or final == "l" then
        local on = final == "h"
        if private:find("?", 1, true) then
            for _, mode in ipairs(p) do
                if mode == 7 then self.wrap = on
                elseif mode == 25 then self.cursor_visible = on
                elseif mode == 1049 or mode == 47 or mode == 1047 then
                    if on and not self.saved_screen then
                        self.saved_screen = self.grid
                        self.saved_cursor = { x = self.x, y = self.y }
                        self.grid = self:newGrid()
                        self.x, self.y = 1, 1
                    elseif not on and self.saved_screen then
                        self.grid = self.saved_screen
                        self.saved_screen = nil
                        if self.saved_cursor then self.x, self.y = self.saved_cursor.x, self.saved_cursor.y end
                        self.saved_cursor = nil
                    end
                end
            end
        end
    elseif final == "n" then
        if a == 5 then self:write("\027[0n")
        elseif a == 6 then self:write(string.format("\027[%d;%dR", self.y, self.x)) end
    elseif final == "c" then
        self:write("\027[?1;2c")
    end
end

function Session:feed(data)
    if not data or data == "" then return end
    data = (self.pending_utf8 or "") .. data
    self.pending_utf8 = ""
    local i = 1
    while i <= #data do
        local ch = data:sub(i, i)
        local byte = data:byte(i)
        if self.parser_state == "normal" then
            if ch == "\027" then
                self.parser_state = "esc"
            elseif byte == 0x9b then
                self.parser_state, self.csi_buf = "csi", ""
            elseif byte == 0x9d then
                self.parser_state, self.osc_buf = "osc", ""
            elseif ch == "\r" then
                self.x, self.wrap_pending = 1, false
            elseif ch == "\n" then
                self:lineFeed()
            elseif ch == "\b" then
                self.x, self.wrap_pending = math.max(1, self.x - 1), false
            elseif byte == 127 then
                -- DEL is ignored by terminals; it is not Backspace.
            elseif byte == 0x9c then
                self.parser_state = "normal"
            elseif ch == "\t" then
                self.x = math.min(self.cols, (math.floor((self.x - 1) / 8) + 1) * 8 + 1)
            elseif byte >= 32 and byte < 127 then
                self:putChar(ch)
            elseif byte >= 194 then
                local len = byte >= 240 and 4 or (byte >= 224 and 3 or 2)
                if i + len - 1 > #data then
                    self.pending_utf8 = data:sub(i)
                    break
                end
                self:putChar(data:sub(i, i + len - 1))
                i = i + len - 1
            end
        elseif self.parser_state == "esc" then
            if ch == "[" then self.parser_state, self.csi_buf = "csi", ""
            elseif ch == "]" then self.parser_state, self.osc_buf = "osc", ""
            elseif ch == "7" then self.saved_cursor = { x = self.x, y = self.y, fg = self.fg, bg = self.bg,
        fg_source = self.fg_source, bg_source = self.bg_source,
        fg_palette_index = self.fg_palette_index, bg_palette_index = self.bg_palette_index,
        bold = self.bold, underline = self.underline, inverse = self.inverse }; self.parser_state = "normal"
            elseif ch == "8" and self.saved_cursor then
                self.x, self.y = self.saved_cursor.x, self.saved_cursor.y
                self.fg, self.bg = self.saved_cursor.fg or self.fg, self.saved_cursor.bg or self.bg
                self.fg_source, self.bg_source = self.saved_cursor.fg_source, self.saved_cursor.bg_source
                self.fg_palette_index, self.bg_palette_index = self.saved_cursor.fg_palette_index, self.saved_cursor.bg_palette_index
                self.bold, self.underline, self.inverse = self.saved_cursor.bold or false, self.saved_cursor.underline or false, self.saved_cursor.inverse or false
                self.parser_state = "normal"
            elseif ch == "D" then self:lineFeed(); self.parser_state = "normal"
            elseif ch == "E" then self.x = 1; self:lineFeed(); self.parser_state = "normal"
            elseif ch == "M" then self:reverseIndex(); self.parser_state = "normal"
            elseif ch == "c" then self:resetScreen(); self.parser_state = "normal"
            elseif ch == "(" or ch == ")" or ch == "*" or ch == "+"
                    or ch == "-" or ch == "." or ch == "/" or ch == "#"
                    or ch == "%" or ch == " " then
                -- Consume the following designator byte in sequences such as
                -- ESC ( B / ESC ) B / ESC % G. Printing that trailing B was
                -- the source of stray literal B characters with some TUIs.
                self.parser_state = "esc_intermediate"
            else self.parser_state = "normal" end
        elseif self.parser_state == "esc_intermediate" then
            -- The final byte selects a character set or DEC mode; the current
            -- renderer uses Unicode directly, so consume it without drawing it.
            self.parser_state = "normal"
        elseif self.parser_state == "csi" then
            if byte >= 0x40 and byte <= 0x7e then
                self:handleCSI(self.csi_buf, ch)
                self.csi_buf = ""
                self.parser_state = "normal"
            elseif #self.csi_buf < 96 then
                self.csi_buf = self.csi_buf .. ch
            else
                self.csi_buf = ""
                self.parser_state = "normal"
            end
        elseif self.parser_state == "osc" then
            if ch == "\007" or byte == 0x9c then self.osc_buf = ""; self.parser_state = "normal"
            elseif ch == "\027" then self.parser_state = "osc_esc"
            elseif #self.osc_buf < 512 then self.osc_buf = self.osc_buf .. ch end
        elseif self.parser_state == "osc_esc" then
            if ch == "\\" then self.osc_buf = ""; self.parser_state = "normal"
            else self.parser_state = "osc" end
        end
        i = i + 1
    end
end

local function cell_style(cell)
    local fg, bg = cell.fg or DEFAULT_FG, cell.bg or DEFAULT_BG
    if cell.inverse then fg, bg = bg, fg end
    return fg, bg, cell.bold, cell.underline
end

function Session:rowToHTML(row, y, cursor_on)
    local last = 1
    for x = self.cols, 1, -1 do
        local c = row[x]
        if c.ch ~= " " or c.bg ~= DEFAULT_BG or c.fg ~= DEFAULT_FG or c.bold or c.underline or c.inverse then
            last = x
            break
        end
    end
    if cursor_on and y == self.y then last = math.max(last, self.x) end
    local chunks, last_style, buffer = {}, nil, {}
    local function flush()
        if #buffer == 0 then return end
        local fg, bg, bold, underline = last_style.fg, last_style.bg, last_style.bold, last_style.underline
        -- Let KOReader's global night-mode inversion run once on the framebuffer.
        -- CSS colors are pre-inverted here so the displayed colors remain correct.
        fg, bg = renderColor(fg), renderColor(bg)
        local styles = "color:" .. fg .. ";background-color:" .. bg .. ";"
            .. (bold and "font-weight:bold;" or "")
            .. (underline and "text-decoration:underline;" or "")
        chunks[#chunks + 1] = '<span style="' .. styles .. '">' .. table.concat(buffer) .. "</span>"
        buffer = {}
    end
    for x = 1, last do
        local cell = row[x]
        local fg, bg, bold, underline = cell_style(cell)
        local ch = cell.ch or " "
        local is_cursor = cursor_on and y == self.y and x == self.x
        if is_cursor then
            fg, bg = bg, fg
            if ch == " " then ch = "_" end
        end
        local style_key = table.concat({ fg, bg, bold and "1" or "0", underline and "1" or "0" }, ":")
        if not last_style or last_style.key ~= style_key then
            flush()
            last_style = { key = style_key, fg = fg, bg = bg, bold = bold, underline = underline }
        end
        buffer[#buffer + 1] = html_escape(ch)
    end
    flush()
    if #chunks == 0 then return " " end
    return table.concat(chunks)
end

function Session:screenHTML()
    -- This is a fixed terminal grid, not a paginated document. Render every
    -- cell row so full-screen TUIs (htop, top, etc.) retain their layout, and
    -- let the viewport geometry determine how many rows the PTY advertises.
    local lines = {}
    for y = 1, self.rows do
        lines[#lines + 1] = self:rowToHTML(self.grid[y], y, not self.finished and self.cursor_visible)
    end
    -- Keep quote characters inside the HTML style attribute valid. Double
    -- quotes around font names terminate the surrounding style attribute and
    -- can make MuPDF drop or misparse the entire terminal block.
    return '<pre style="background-color:' .. renderColor(DEFAULT_BG)
        .. ';color:' .. renderColor(DEFAULT_FG)
        .. ";font-family:'Noto Sans Mono','DejaVu Sans Mono',monospace;white-space:pre;line-height:1;margin:0;padding:0;\">"
        .. table.concat(lines, "\n") .. '</pre>'
end

function Session:historyHTML()
    local lines = {}
    for i, row in ipairs(self.history) do lines[#lines + 1] = self:rowToHTML(row, -i, false) end
    for y = 1, self.rows do lines[#lines + 1] = self:rowToHTML(self.grid[y], y, false) end
    return '<pre style="background-color:' .. renderColor(DEFAULT_BG) .. ';color:' .. renderColor(DEFAULT_FG) .. ';margin:0;padding:0;">'
        .. table.concat(lines, "\n") .. '</pre>'
end

function Session:updateViewer(force)
    if not self.viewer or self.closed or self.viewer_closing then return end
    self:updateTheme()
    local html = self:screenHTML()
    if not force and html == self.last_html then return end
    self.last_html = html
    self.viewer.text = html
    local viewer = self.viewer
    local scroll = viewer.scroll_widget
    if not scroll or not scroll.htmlbox_widget then return end
    local box = scroll.htmlbox_widget
    local ok, render_err = pcall(function()
        -- HtmlBoxWidget:setContent() creates a new MuPDF document but does
        -- not invalidate its cached rendered bitmap (box.bb) or close the
        -- previous document. Invalidate the bitmap on every screen update so
        -- new SSH output is actually painted, then release the old document
        -- after the new one has loaded. Doing all of this in one UI callback
        -- avoids an intermediate blank paint.
        local old_document = box.document
        if box.freeBb then box:freeBb() end
        scroll.html_body = html
        local fg, bg = themeColors()
        -- The HTML widget's explicit CSS is not theme-aware; compensate for
        -- KOReader's framebuffer inversion when night mode is active.
        local render_fg, render_bg = renderColor(fg), renderColor(bg)
        local css = (scroll.css or "") .. string.format([[
html, body { background-color: %s !important; color: %s; margin: 0; padding: 0; }
body { line-height: 1; }
pre { background-color: %s !important; color: %s; font-family: "Noto Sans Mono", "DejaVu Sans Mono", monospace; white-space: pre; line-height: 1; margin: 0; padding: 0; }
]], render_bg, render_fg, render_bg, render_fg)
        box:setContent(html, css, scroll.default_font_size, false, nil, nil)
        if old_document and old_document ~= box.document then
            pcall(function() old_document:close() end)
        end
        if box.page_number ~= 1 then box:setPageNumber(1) end
        scroll.v_scroll_bar.enable = false
        scroll:_updateScrollBar()
        self:applyThemeBackground()
        -- UI refreshes do not count toward KOReader's full-refresh promotion,
        -- unlike repeated partial refreshes.
        UIManager:setDirty(viewer, "ui", viewer.frame.dimen)
    end)
    if not ok and not self.render_warned then
        self.render_warned = true
        UIManager:show(InfoMessage:new{
            text = _("Colour terminal redraw failed: ") .. tostring(render_err),
            timeout = 5,
        })
    end
end

function Session:applyThemeBackground()
    if not self.viewer then return end
    -- Do not manually make this widget black in night mode: the framebuffer
    -- inversion would turn that explicit black into white. Use the normal
    -- pre-inversion background and let KOReader invert the whole UI once.
    local bg = Blitbuffer.COLOR_WHITE
    pcall(function()
        if self.viewer.frame then self.viewer.frame.background = bg end
        if self.viewer.textw then self.viewer.textw.background = bg end
    end)
end

function Session:applyBlackBackground()
    return self:applyThemeBackground()
end

function Session:syncSizeToViewer()
    if self.closed or not self.viewer then return false end
    local cols, rows = getTerminalSize(self.viewer)
    if cols ~= self.cols or rows ~= self.rows then
        self:resizeScreen(cols, rows)
        self.last_html = nil
        return true
    end
    return false
end

function Session:write(data)
    if self.closed or not self.master or not data or data == "" then return false end
    local offset = 1
    while offset <= #data do
        local wrote = tonumber(C.write(self.master, data:sub(offset), #data - offset + 1))
        if not wrote or wrote <= 0 then return false end
        offset = offset + wrote
    end
    return true
end

local function make_button(text, callback, id)
    local item = { text = text, callback = callback, vsync = true }
    if id then item.id = id end
    return item
end

local SHIFTED = {
    ["`"] = "~", ["1"] = "!", ["2"] = "@", ["3"] = "#", ["4"] = "$",
    ["5"] = "%", ["6"] = "^", ["7"] = "&", ["8"] = "*", ["9"] = "(",
    ["0"] = ")", ["-"] = "_", ["="] = "+", ["["] = "{", ["]"] = "}",
    ["\\"] = "|", [";"] = ":", ["'"] = '"', [","] = "<", ["."] = ">", ["/"] = "?",
}

function Session:updateModifierButton(id, label)
    if not self.viewer or not self.viewer.button_table then return end
    local button = self.viewer.button_table:getButtonById(id)
    if button then
        button:setText(label, button.width)
        button:refresh()
    end
end

function Session:updateShiftLabels()
    if not self.viewer or not self.viewer.button_table or self.symbol_mode then return end
    for ch in ("qwertyuiopasdfghjklzxcvbnm"):gmatch(".") do
        local button = self.viewer.button_table:getButtonById("ssh_key_" .. ch)
        if button then
            button:setText(self.keyboard_shift and ch:upper() or ch, button.width)
            button:refresh()
        end
    end
end

function Session:sendTypedKey(value)
    if self.closed or not value then return end
    local data = value
    local was_shifted = self.keyboard_shift
    if self.keyboard_ctrl then
        local lower = value:lower()
        local byte = lower:byte(1)
        if byte and byte >= 97 and byte <= 122 then
            data = string.char(byte - 96)
        elseif value == "[" then data = "\027"
        elseif value == "\\" then data = "\028"
        elseif value == "]" then data = "\029"
        elseif value == "^" then data = "\030"
        elseif value == "_" then data = "\031"
        elseif value == "?" then data = "\127"
        elseif value == " " then data = "\000"
        end
    elseif self.keyboard_shift then
        data = SHIFTED[value] or value:upper()
    end
    self.keyboard_shift = false
    self.keyboard_ctrl = false
    self:write(data)
    self:updateModifierButton("ssh_ctrl", "Ctrl")
    self:updateModifierButton("ssh_shift", "Shift")
    if was_shifted then self:updateShiftLabels() end
end

function Session:toggleCtrl()
    self.keyboard_ctrl = not self.keyboard_ctrl
    self:updateModifierButton("ssh_ctrl", self.keyboard_ctrl and "Ctrl*" or "Ctrl")
end

function Session:toggleShift()
    self.keyboard_shift = not self.keyboard_shift
    self:updateModifierButton("ssh_shift", self.keyboard_shift and "Shift*" or "Shift")
    self:updateShiftLabels()
end

function Session:buildButtonsTable()
    local session = self
    local function send(label, data, id)
        return make_button(label, function()
            if session.closed then return end
            session:write(data)
            local was_shifted = session.keyboard_shift
            if session.keyboard_shift or session.keyboard_ctrl then
                session.keyboard_shift = false
                session.keyboard_ctrl = false
                session:updateModifierButton("ssh_ctrl", "Ctrl")
                session:updateModifierButton("ssh_shift", "Shift")
            end
            if was_shifted then session:updateShiftLabels() end
        end, id)
    end
    local function typed(ch, label, id)
        return make_button(label or ch, function() session:sendTypedKey(ch) end, id)
    end
    local function toggle(label, callback, id)
        return make_button(label, callback, id)
    end
    local function hide_keyboard()
        session.keyboard_expanded = false
        session.symbol_mode = false
        session.keyboard_shift = false
        session.keyboard_ctrl = false
        session:refreshViewerLayout()
    end
    local function toggle_symbols()
        session.symbol_mode = not session.symbol_mode
        session.keyboard_shift = false
        session.keyboard_ctrl = false
        session:refreshViewerLayout()
    end
    local function quick(text, data)
        return send(text, data)
    end

    if not self.keyboard_expanded then
        return {
            {
                toggle("Keyboard", function()
                    session.keyboard_expanded = true
                    session.symbol_mode = false
                    session.keyboard_shift = false
                    session.keyboard_ctrl = false
                    session:refreshViewerLayout()
                end, "ssh_keyboard"),
                quick("Tab", "\t"), quick("Esc", "\027"), quick("Ctrl-C", "\003"), quick("Ctrl-D", "\004"),
            },
            {
                quick("←", "\027[D"), quick("↑", "\027[A"), quick("↓", "\027[B"), quick("→", "\027[C"),
                quick("Ctrl-L", "\014"),
                make_button("Scroll", function() session:showScrollback() end),
                make_button("Close", function() session:closeViewer() end, "close"),
            },
        }
    end

    if self.symbol_mode then
        return {
            {
                toggle("ABC", toggle_symbols, "ssh_keyboard"),
                toggle(self.keyboard_ctrl and "Ctrl*" or "Ctrl", function() session:toggleCtrl() end, "ssh_ctrl"),
                quick("Tab", "\t"), quick("Esc", "\027"), quick("Ctrl-C", "\003"),
                quick("←", "\027[D"), quick("↑", "\027[A"), quick("↓", "\027[B"), quick("→", "\027[C"),
                toggle("Done", hide_keyboard),
            },
            {
                typed("1"), typed("2"), typed("3"), typed("4"), typed("5"),
                typed("6"), typed("7"), typed("8"), typed("9"), typed("0"),
            },
            {
                typed("~"), typed("!"), typed("@"), typed("#"), typed("$"),
                typed("%"), typed("^"), typed("&"), typed("*"), typed("("), typed(")"),
            },
            {
                typed("-"), typed("_"), typed("+"), typed("="), typed("["),
                typed("]"), typed("{"), typed("}"), typed("\\"), typed("|"), typed("/"),
            },
            {
                typed(":"), typed(";"), typed("'"), typed('"'), typed("`"), typed("?"),
                typed(" ", "Space"), send("Enter", "\r"), send("⌫", "\127"),
            },
        }
    end

    local row_letters = {}
    for ch in ("qwertyuiop"):gmatch(".") do row_letters[#row_letters + 1] = typed(ch, self.keyboard_shift and ch:upper() or ch, "ssh_key_" .. ch) end
    local home_letters = {}
    for ch in ("asdfghjkl"):gmatch(".") do home_letters[#home_letters + 1] = typed(ch, self.keyboard_shift and ch:upper() or ch, "ssh_key_" .. ch) end
    local bottom_letters = {}
    for ch in ("zxcvbnm"):gmatch(".") do bottom_letters[#bottom_letters + 1] = typed(ch, self.keyboard_shift and ch:upper() or ch, "ssh_key_" .. ch) end

    return {
        {
            toggle("Done", hide_keyboard),
            toggle("123", toggle_symbols, "ssh_keyboard"),
            toggle(self.keyboard_ctrl and "Ctrl*" or "Ctrl", function() session:toggleCtrl() end, "ssh_ctrl"),
            quick("Tab", "\t"), quick("Esc", "\027"), quick("Ctrl-C", "\003"),
            make_button("Close", function() session:closeViewer() end, "close"),
        },
        row_letters,
        (function()
            home_letters[#home_letters + 1] = send("Enter", "\r")
            return home_letters
        end)(),
        (function()
            local row = { toggle(self.keyboard_shift and "Shift*" or "Shift", function() session:toggleShift() end, "ssh_shift") }
            for _, button in ipairs(bottom_letters) do row[#row + 1] = button end
            row[#row + 1] = send("⌫", "\127")
            return row
        end)(),
        {
            send("Space", " "), send("←", "\027[D"), send("↑", "\027[A"), send("↓", "\027[B"),
            send("→", "\027[C"), send("Home", "\027[H"), send("End", "\027[F"),
            send("PgUp", "\027[5~"), send("PgDn", "\027[6~"),
        },
    }
end

function Session:makeButtonsResponsive()
    if not self.viewer then return end
    local button_table = self.viewer.button_table
    if not button_table or not button_table.buttons_layout then return end

    local session = self
    for _, row in ipairs(button_table.buttons_layout) do
        for _, button in ipairs(row) do
            if button and not button._sshclient_fast_tap then
                button._sshclient_fast_tap = true
                -- Zen OS-style tap path: repaint only the key region with a fast
                -- update, execute the callback immediately, and never block on
                -- forceRePaint()/yieldToEPDC()/waitForVSync() for each character.
                button.onTapSelectButton = function(key)
                    if not key.enabled and not key.allow_tap_when_disabled then return true end
                    if key._sshclient_feedback_release then
                        UIManager:unschedule(key._sshclient_feedback_release)
                        key._sshclient_feedback_release = nil
                    end
                    local frame = key[1]
                    local bounds = frame and frame.dimen
                    if bounds then
                        frame.invert = true
                        UIManager:widgetRepaint(frame, bounds.x, bounds.y)
                        UIManager:setDirty(nil, "fast", bounds)
                    end
                    pcall(Device.performHapticFeedback, Device, "KEYBOARD_TAP")
                    if key.callback then
                        key.callback()
                    elseif key.tap_input then
                        key:onInput(key.tap_input)
                    elseif key.tap_input_func then
                        key:onInput(key.tap_input_func())
                    end
                    if bounds then
                        local function release_feedback()
                            key._sshclient_feedback_release = nil
                            -- Layout-changing actions rebuild the button table;
                            -- do not repaint stale widgets after that happens.
                            if session.closed or not session.viewer
                                    or session.viewer.button_table ~= button_table
                                    or key[1] ~= frame then return end
                            frame.invert = false
                            UIManager:widgetRepaint(frame, bounds.x, bounds.y)
                            UIManager:setDirty(nil, "fast", bounds)
                        end
                        key._sshclient_feedback_release = release_feedback
                        UIManager:scheduleIn(0.09, release_feedback)
                    end
                    return true
                end
            end
        end
    end
end

function Session:refreshViewerLayout()
    if self.closed or not self.viewer then return end
    self.viewer.buttons_table = self:buildButtonsTable()
    self.viewer.text = self:screenHTML()
    local ok, err = pcall(function() self.viewer:reinit() end)
    if not ok then
        self.last_html = nil
        if not self.layout_warned then
            self.layout_warned = true
            UIManager:show(InfoMessage:new{ text = _("Could not update SSH keyboard layout: ") .. tostring(err), timeout = 4 })
        end
        return
    end
    self:makeButtonsResponsive()
    self:applyThemeBackground()
    -- Recalculate rows from the actual area left after the keyboard dock is
    -- laid out. A real PTY resize lets htop and other TUIs redraw correctly.
    self:syncSizeToViewer()
    self:updateViewer(true)
end

function Session:makeViewer()
    local viewer = TextViewer:new{
        title = _("SSH · ") .. self.host_label,
        -- Keep the terminal edge-to-edge, with the keyboard docked below it.
        width = Screen:getWidth(),
        height = Screen:getHeight(),
        text_padding = 0,
        text_margin = 0,
        button_padding = 0,
        text = self:screenHTML(),
        text_format = "html",
        text_type = "ssh_terminal",
        text_types = { ssh_terminal = { monospace_font = true, font_size = 13, justified = false } },
        monospace_font = true,
        justified = false,
        auto_para_direction = false,
        show_menu = false,
        add_default_buttons = false,
        -- Zen OS's responsive-keyboard path uses this flag to allow the next
        -- tap to register without waiting for the current touch to fully end.
        allow_concurrent_taps = true,
        buttons_table = self:buildButtonsTable(),
    }
    return viewer
end

-- Close the display and process in a deliberate order. Marking the session
-- closed first prevents a scheduled poll from redrawing a widget being removed.
function Session:closeViewer()
    if self.viewer_closing then return true end
    self.viewer_closing = true
    self:stop()
    local viewer = self.viewer
    if viewer then
        pcall(function() UIManager:close(viewer) end)
    end
    return true
end

function Session:showScrollback()
    local history_view = TextViewer:new{
        title = _("SSH terminal scrollback — ") .. self.host_label,
        text = self:historyHTML(),
        text_format = "html",
        text_type = "code",
        text_types = { code = { monospace_font = true, font_size = 13, justified = false } },
        monospace_font = true,
        justified = false,
        auto_para_direction = false,
    }
    UIManager:show(history_view)
end

function Session:poll()
    if self.closed or not self.master then return end
    -- Theme changes are local UI events; they must refresh even when the SSH
    -- peer is idle and no bytes arrive to trigger a terminal redraw.
    local theme_changed = self:updateTheme()
    if theme_changed then self.last_html = nil end
    local received = false
    local buf = ffi.new("char[16384]")
    for _ = 1, 8 do
        local n = tonumber(C.read(self.master, buf, 16384))
        if not n or n <= 0 then break end
        self:feed(ffi.string(buf, n))
        received = true
        if n < 16384 then break end
    end
    local status = ffi.new("int[1]")
    local waited = self.pid and tonumber(C.waitpid(self.pid, status, 1)) or -1
    if waited == self.pid and self.pid then
        self.finished = true
        self.reaped = true
        self:feed("\r\n[SSH session ended]\r\n")
        received = true
    end
    if (received or theme_changed) and not self.closed then
        self.render_pending = true
        local now = UIManager:getTime()
        if not self.last_render_time or now - self.last_render_time >= RENDER_INTERVAL then
            self.render_pending = false
            self.last_render_time = now
            self:updateViewer(true)
        end
    end
    if self.render_pending and not self.closed then
        UIManager:scheduleIn(RENDER_INTERVAL, self.poll_fn)
    elseif not self.finished and not self.closed then
        UIManager:scheduleIn(POLL_INTERVAL, self.poll_fn)
    end
end

function Session:stop()
    if self.cleanup_started then return end
    self.cleanup_started = true
    self.closed = true

    if self.poll_fn then
        pcall(function() UIManager:unschedule(self.poll_fn) end)
        self.poll_fn = nil
    end
    local keyboard = self.keyboard_dialog
    self.keyboard_dialog = nil
    if keyboard then pcall(function() UIManager:close(keyboard) end) end

    local master = self.master
    self.master = nil
    if master then
        -- The child calls setsid(), so terminate the entire SSH process group,
        -- not just its shell wrapper. Reap the child before releasing the PTY.
        if self.pid and not self.reaped then
            pcall(C.kill, -self.pid, 15) -- SIGTERM to session/process group
            local status = ffi.new("int[1]")
            local waited = tonumber(C.waitpid(self.pid, status, 1))
            if waited == self.pid then
                self.reaped = true
            elseif waited == 0 then
                pcall(C.kill, -self.pid, 9) -- SIGKILL the process group
                pcall(C.kill, self.pid, 9) -- direct-child fallback
                local ok, result = pcall(C.waitpid, self.pid, status, 0)
                if ok and tonumber(result) == self.pid then self.reaped = true end
            else
                -- ECHILD means it was already reaped; don't wait on it again.
                self.reaped = true
            end
        end
        pcall(C.close, master)
    end
end

getTerminalSize = function(viewer)
    local face = Font:getFace("smallinfont", 13)
    local sample = TextWidget:new{ text = "M", face = face, padding = 0 }
    local char_w = math.max(1, sample:getSize().w)
    local font_px = math.max(1, Screen:scaleBySize(13))
    local viewport_w, viewport_h

    if viewer and viewer.scroll_widget and viewer.scroll_widget.htmlbox_widget then
        local dimen = viewer.scroll_widget.htmlbox_widget.dimen
        viewport_w, viewport_h = dimen.w, dimen.h
    else
        -- A safe initial PTY size. After the TextViewer is laid out, syncSizeToViewer
        -- resizes it to the exact area available to the terminal.
        viewport_w = Screen:getWidth() - Screen:scaleBySize(20)
        viewport_h = font_px * 24
    end

    -- The HTML renderer uses the scaled TextViewer code font and line-height:1.
    -- Use a slight width/height safety margin to avoid wrapping and page splits.
    local cols = clamp(math.floor((viewport_w - Screen:scaleBySize(8)) / (char_w * 1.02)), 60, 160)
    local rows = clamp(math.floor((viewport_h - Screen:scaleBySize(8)) / font_px), 8, 100)
    return cols, rows
end

local function open_pty(command, cols, rows)
    local flags = bit.bor(C.O_RDWR, C.O_NONBLOCK, C.O_CLOEXEC)
    local master = C.open("/dev/ptmx", flags)
    if master == -1 then
        return nil, "Cannot open /dev/ptmx: " .. ffi.string(C.strerror(ffi.errno()))
    end
    if C.grantpt(master) ~= 0 or C.unlockpt(master) ~= 0 then
        local err = ffi.string(C.strerror(ffi.errno()))
        C.close(master)
        return nil, "Cannot initialize pseudo-terminal: " .. err
    end
    local name = C.ptsname(master)
    if name == nil then
        local err = ffi.string(C.strerror(ffi.errno()))
        C.close(master)
        return nil, "Cannot locate pseudo-terminal: " .. err
    end
    local slave_path = ffi.string(name)
    local pid = tonumber(C.fork())
    if pid == nil or pid < 0 then
        local err = ffi.string(C.strerror(ffi.errno()))
        C.close(master)
        return nil, "Cannot start SSH process: " .. err
    elseif pid == 0 then
        C.close(master)
        C.setsid()
        local slave = C.open(slave_path, C.O_RDWR)
        if slave < 0 then os.exit(127) end
        C.dup2(slave, 0); C.dup2(slave, 1); C.dup2(slave, 2)
        if slave > 2 then C.close(slave) end
        C.setenv("TERM", "xterm-256color", 1)
        C.setenv("COLORTERM", "truecolor", 1)
        C.setenv("LINES", tostring(rows), 1)
        C.setenv("COLUMNS", tostring(cols), 1)
        os.execute("stty cols " .. tostring(cols) .. " rows " .. tostring(rows) .. " 2>/dev/null")
        -- The command has been assembled with shell_quote() by the parent plugin.
        C.execl("/bin/sh", "sh", "-c", "exec " .. command, nil)
        os.exit(127)
    end
    return { master = master, pid = pid, cols = cols, rows = rows }
end

function ColorTerminal.open(options)
    options = options or {}
    local cols, rows = getTerminalSize(false)
    local ok, pty, err = pcall(open_pty, options.command or "", cols, rows)
    if not ok then err, pty = tostring(pty), nil end
    if not pty then
        UIManager:show(InfoMessage:new{ text = err or _("Unable to start the custom SSH terminal."), timeout = 5 })
        return false
    end
    local self = setmetatable({
        host_label = options.host_label or "SSH host",
        master = pty.master,
        pid = pty.pid,
        cols = pty.cols,
        rows = pty.rows,
        history = {},
        parser_state = "normal",
        csi_buf = "",
        pending_utf8 = "",
        finished = false,
        reaped = false,
        closed = false,
        cleanup_started = false,
        viewer_closing = false,
        keyboard_shift = false,
        keyboard_ctrl = false,
        keyboard_expanded = false,
        symbol_mode = false,
    }, Session)
    self.theme_fg, self.theme_bg = themeColors()
    self.theme_night = nightMode()
    self:resetScreen()
    self.viewer = self:makeViewer()
    -- TextViewer calls onClose for its close button, outside tap, and multi-swipe.
    -- Intercept all of them so cleanup happens before the view is removed. Also
    -- keep a close-widget hook for external UIManager close paths.
    local viewer = self.viewer
    viewer.onClose = function() return self:closeViewer() end
    local original_on_close_widget = viewer.onCloseWidget
    viewer.onCloseWidget = function(widget)
        self:stop()
        if original_on_close_widget then return original_on_close_widget(widget) end
    end
    self.poll_fn = function() self:poll() end
    enableConcurrentTapSupport()
    UIManager:show(self.viewer)
    self:makeButtonsResponsive()
    self:applyThemeBackground()
    self:syncSizeToViewer()
    self:updateViewer(true)
    UIManager:scheduleIn(POLL_INTERVAL, self.poll_fn)
    return true
end

return ColorTerminal
