-- sshclient.koplugin
-- SSH CLIENT for KOReader. This plugin connects FROM the Kindle TO other hosts.
-- It does not start or configure an SSH server on the Kindle.
--
-- The preferred transport is KOReader's bundled Dropbear dbclient. Because
-- some noframework / customized installs use different paths, the executable
-- path can be configured from the plugin menu.

local ButtonDialog = require("ui/widget/buttondialog")
local DataStorage = require("datastorage")
local Dispatcher = require("dispatcher")
local InfoMessage = require("ui/widget/infomessage")
local InputDialog = require("ui/widget/inputdialog")
local LuaSettings = require("luasettings")
local TextViewer = require("ui/widget/textviewer")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local Device = require("device")
local _ = require("gettext")

local Screen = Device.screen

local SSHClient = WidgetContainer:extend{
    name = "sshclient",
    -- The client must be available from the file-browser/home menu even when
    -- no book is open. Without this flag KOReader may treat it as doc-only.
    is_doc_only = false,
    title = _("SSH Client"),
    settings_file = DataStorage:getSettingsDir() .. "/sshclient.lua",
    settings = nil,
    hosts = nil,
    client_path_override = nil,
}

local function trim(value)
    return (tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

-- POSIX-shell quoting. User-entered host names, key paths and remote commands
-- are always passed as quoted arguments rather than interpolated raw.
local function shell_quote(value)
    return "'" .. tostring(value or ""):gsub("'", "'\\''") .. "'"
end

local function read_file(path)
    local f = io.open(path, "rb")
    if not f then return nil end
    local value = f:read("*a")
    f:close()
    return value
end

local function file_exists(path)
    local f = io.open(path, "rb")
    if not f then return false end
    f:close()
    return true
end

local function is_executable(path)
    if not path or path == "" then return false end
    -- io.popen/test are present on standard KOReader LuaJIT builds. If popen
    -- is restricted on a custom build, fall back to checking for the file and
    -- let the actual invocation report any permission problem.
    local ok, pipe = pcall(io.popen, "test -x " .. shell_quote(path) .. " && echo yes", "r")
    if ok and pipe then
        local result = pipe:read("*l")
        pipe:close()
        return result == "yes"
    end
    return file_exists(path)
end

local function command_path(name)
    if not name:match("^[%w._%-]+$") then return nil end
    local ok, pipe = pcall(io.popen, "command -v " .. name .. " 2>/dev/null", "r")
    if not ok or not pipe then return nil end
    local result = trim(pipe:read("*l"))
    pipe:close()
    if result ~= "" and is_executable(result) then return result end
    return nil
end

local function clone_host(host)
    return {
        name = host.name or "",
        host = host.host or "",
        user = host.user or "root",
        port = tonumber(host.port) or 22,
        key = host.key or "",
        trust_first_use = host.trust_first_use == true,
    }
end

local function host_target(host)
    return tostring(host.user or "root") .. "@" .. tostring(host.host or "")
end

function SSHClient:init()
    self.settings = LuaSettings:open(self.settings_file)
    self.hosts = self.settings:readSetting("hosts", {}) or {}
    self.client_path_override = self.settings:readSetting("client_path", nil)
    self:onDispatcherRegisterActions()
    self.ui.menu:registerToMainMenu(self)
end

function SSHClient:onDispatcherRegisterActions()
    Dispatcher:registerAction(
        "sshclient_open",
        { category = "none", event = "OpenSSHClient", title = _("SSH Client"), general = true, separator = true }
    )
end

function SSHClient:addToMainMenu(menu_items)
    menu_items.sshclient = {
        text = _("SSH Client"),
        -- Standard non-document plugin placement: Tools > More tools.
        sorting_hint = "more_tools",
        callback = function() self:showHosts() end,
    }
end

function SSHClient:onOpenSSHClient()
    self:showHosts()
end

function SSHClient:saveSettings()
    self.settings:saveSetting("hosts", self.hosts)
    self.settings:saveSetting("client_path", self.client_path_override)
    self.settings:flush()
end

function SSHClient:findClient()
    if self.client_path_override and self.client_path_override ~= ""
        and is_executable(self.client_path_override) then
        return self.client_path_override
    end

    local full_dir = DataStorage:getFullDataDir()
    local candidates = {}
    if full_dir and full_dir ~= "" then
        table.insert(candidates, full_dir .. "/dbclient")
        table.insert(candidates, full_dir .. "/bin/dbclient")
    end
    table.insert(candidates, "/mnt/us/koreader/dbclient")
    table.insert(candidates, "/mnt/us/koreader/bin/dbclient")
    table.insert(candidates, "/usr/bin/dbclient")
    table.insert(candidates, "/usr/local/bin/dbclient")
    table.insert(candidates, "/bin/dbclient")
    table.insert(candidates, "/usr/bin/ssh")
    table.insert(candidates, "/usr/local/bin/ssh")
    table.insert(candidates, "/bin/ssh")
    for _, path in ipairs(candidates) do
        if path and is_executable(path) then return path end
    end

    return command_path("dbclient") or command_path("ssh")
end

-- Access KOReader's own terminal-emulator plugin instance. It owns a real
-- pseudo-terminal and handles the Kindle keyboard, terminal escape sequences,
-- and remote SSH prompts; no external kterm binary is needed.
function SSHClient:getBuiltinTerminal()
    local terminal = self.ui and self.ui.terminal
    if terminal and terminal.onTerminalStart and terminal.transmit and terminal.spawnShell then
        return terminal
    end

    -- Some KOReader builds expose plugin instances through PluginLoader rather
    -- than the current UI object. Keep this lookup optional for noframework builds.
    local ok, PluginLoader = pcall(require, "pluginloader")
    if ok and PluginLoader and PluginLoader.getPluginInstance then
        local success, instance = pcall(PluginLoader.getPluginInstance, PluginLoader, "terminal")
        if success and instance and instance.onTerminalStart and instance.transmit and instance.spawnShell then
            return instance
        end
    end
    return nil
end

function SSHClient:hostLabel(host)
    local label = host.name and host.name ~= "" and host.name or host_target(host)
    return string.format("%s\n%s  ·  port %s", label, host_target(host), tostring(host.port or 22))
end

function SSHClient:showHosts()
    local buttons = {}
    for index, host in ipairs(self.hosts) do
        local i = index
        local item = host
        table.insert(buttons, {{
            text = self:hostLabel(item),
            callback = function()
                if self.host_dialog then UIManager:close(self.host_dialog) end
                self:showHostActions(i)
            end,
        }})
    end
    table.insert(buttons, {{
        text = _("+ Add host"),
        callback = function()
            if self.host_dialog then UIManager:close(self.host_dialog) end
            self:startHostWizard(nil)
        end,
    }})
    table.insert(buttons, {{
        text = _("SSH client status / executable"),
        callback = function()
            if self.host_dialog then UIManager:close(self.host_dialog) end
            self:showClientStatus()
        end,
    }})
    table.insert(buttons, {{
        text = _("Help and security notes"),
        callback = function()
            if self.host_dialog then UIManager:close(self.host_dialog) end
            self:showHelp()
        end,
    }})
    table.insert(buttons, {{ text = _("Close"), callback = function()
        if self.host_dialog then UIManager:close(self.host_dialog) end
    end }})

    self.host_dialog = ButtonDialog:new{
        title = _("SSH Client — connect to another device"),
        buttons = buttons,
        width = math.floor(Screen:getWidth() * 0.94),
    }
    UIManager:show(self.host_dialog)
end

function SSHClient:showHostActions(index)
    local host = self.hosts[index]
    if not host then return self:showHosts() end

    local dialog
    local trust_label = host.trust_first_use and _("Disable automatic first-use host-key acceptance")
        or _("Allow automatic first-use host-key acceptance…")
    dialog = ButtonDialog:new{
        title = self:hostLabel(host),
        width = math.floor(Screen:getWidth() * 0.94),
        buttons = {
            {{ text = _("Open Color SSH Terminal (experimental)"), callback = function()
                UIManager:close(dialog)
                self:openColorTerminal(index)
            end }},
            {{ text = _("Open built-in KOReader terminal (SSH)"), callback = function()
                UIManager:close(dialog)
                self:openInteractive(index)
            end }},
            {{ text = _("Run remote command"), callback = function()
                UIManager:close(dialog)
                self:promptRemoteCommand(index)
            end }},
            {{ text = _("Test connection"), callback = function()
                UIManager:close(dialog)
                self:runRemoteCommand(index, "printf 'SSH connection successful\\n'; hostname; whoami", _("SSH connection test"))
            end }},
            {{ text = _("Edit host"), callback = function()
                UIManager:close(dialog)
                self:startHostWizard(index)
            end }},
            {{ text = trust_label, callback = function()
                UIManager:close(dialog)
                self:toggleTrustFirstUse(index)
            end }},
            {{ text = _("Delete host…"), callback = function()
                UIManager:close(dialog)
                self:confirmDeleteHost(index)
            end }},
            {{ text = _("Back to host list"), callback = function()
                UIManager:close(dialog)
                self:showHosts()
            end }},
        },
    }
    UIManager:show(dialog)
end

function SSHClient:toggleTrustFirstUse(index)
    local host = self.hosts[index]
    if not host then return end
    if host.trust_first_use then
        host.trust_first_use = false
        self:saveSettings()
        UIManager:show(InfoMessage:new{ text = _("Automatic first-use host-key acceptance disabled."), timeout = 2 })
        self:showHostActions(index)
        return
    end

    local dialog
    dialog = ButtonDialog:new{
        title = _("Trust unknown SSH host keys?"),
        buttons = {
            {{ text = _("Enable for this host"), callback = function()
                UIManager:close(dialog)
                host.trust_first_use = true
                self:saveSettings()
                UIManager:show(InfoMessage:new{
                    text = _("Automatic acceptance enabled for unknown first-use host keys. Verify the host identity through a trusted channel; changed known keys should still be rejected by the SSH client."),
                    timeout = 6,
                })
                self:showHostActions(index)
            end }},
            {{ text = _("Cancel"), callback = function() UIManager:close(dialog) end }},
        },
    }
    UIManager:show(dialog)
end

function SSHClient:confirmDeleteHost(index)
    local host = self.hosts[index]
    if not host then return end
    local dialog
    dialog = ButtonDialog:new{
        title = string.format(_("Delete saved host '%s'?"), host.name or host.host or ""),
        buttons = {
            {{ text = _("Delete"), callback = function()
                UIManager:close(dialog)
                table.remove(self.hosts, index)
                self:saveSettings()
                self:showHosts()
            end }},
            {{ text = _("Cancel"), callback = function()
                UIManager:close(dialog)
                self:showHostActions(index)
            end }},
        },
    }
    UIManager:show(dialog)
end

function SSHClient:startHostWizard(index)
    local is_edit = index ~= nil
    local host = is_edit and clone_host(self.hosts[index] or {}) or {
        name = "", host = "", user = "root", port = 22, key = "", trust_first_use = false,
    }
    local fields = {
        { key = "name", title = _("Profile name (for example: Home server)"), input = host.name },
        { key = "host", title = _("Hostname or IP address"), input = host.host },
        { key = "user", title = _("Remote username"), input = host.user },
        { key = "port", title = _("SSH port"), input = tostring(host.port or 22), numeric = true },
        { key = "key", title = _("Private key file path (optional)"), input = host.key },
    }

    local function ask_field(field_index)
        local field = fields[field_index]
        if not field then
            host.name = trim(host.name)
            host.host = trim(host.host)
            host.user = trim(host.user)
            host.key = trim(host.key)
            local parsed_port = tonumber(host.port)
            if host.host == "" then
                UIManager:show(InfoMessage:new{ text = _("Hostname/IP is required."), timeout = 2 })
                ask_field(2)
                return
            end
            if host.user == "" then
                UIManager:show(InfoMessage:new{ text = _("Remote username is required."), timeout = 2 })
                ask_field(3)
                return
            end
            if not parsed_port or parsed_port < 1 or parsed_port > 65535 or parsed_port ~= math.floor(parsed_port) then
                UIManager:show(InfoMessage:new{ text = _("Port must be a number from 1 to 65535."), timeout = 2 })
                fields[4].input = tostring(host.port or "")
                ask_field(4)
                return
            end
            host.port = parsed_port
            if host.name == "" then host.name = host_target(host) end
            if is_edit then
                if self.hosts[index] then self.hosts[index] = host end
            else
                table.insert(self.hosts, host)
                index = #self.hosts
            end
            self:saveSettings()
            UIManager:show(InfoMessage:new{ text = is_edit and _("Host saved.") or _("Host added."), timeout = 1.5 })
            self:showHostActions(index)
            return
        end

        local dialog
        dialog = InputDialog:new{
            title = field.title,
            input = field.input or "",
            input_type = field.numeric and "number" or nil,
            buttons = {
                {{ text = _("Cancel"), callback = function() UIManager:close(dialog) end }},
                {{ text = field_index == #fields and _("Save") or _("Next"), callback = function()
                    local value = trim(dialog:getInputText())
                    UIManager:close(dialog)
                    field.input = value
                    host[field.key] = value
                    ask_field(field_index + 1)
                end }},
            },
        }
        UIManager:show(dialog)
    end
    ask_field(1)
end

function SSHClient:buildClientCommand(host, remote_command, force_tty)
    local client = self:findClient()
    if not client then return nil end

    local args = { shell_quote(client) }
    if force_tty then table.insert(args, "-t") end
    if host.trust_first_use then
        local lower_client = client:lower()
        if lower_client:match("dbclient") or lower_client:match("dropbear") then
            table.insert(args, "-y")
        else
            -- OpenSSH equivalent for non-interactive first-use acceptance. This
            -- option is supported by current OpenSSH versions; dbclient remains
            -- the preferred Kindle client and is checked first.
            table.insert(args, "-o")
            table.insert(args, shell_quote("StrictHostKeyChecking=accept-new"))
        end
    end
    local port = tonumber(host.port) or 22
    if port ~= 22 then
        table.insert(args, "-p")
        table.insert(args, shell_quote(tostring(port)))
    end
    if host.key and trim(host.key) ~= "" then
        table.insert(args, "-i")
        table.insert(args, shell_quote(trim(host.key)))
    end
    table.insert(args, shell_quote(host_target(host)))
    if remote_command and remote_command ~= "" then
        table.insert(args, shell_quote(remote_command))
    end
    return table.concat(args, " ")
end

function SSHClient:openInteractive(index)
    local host = self.hosts[index]
    if not host then return end

    local client = self:findClient()
    if not client then
        self:showClientMissing()
        return
    end

    local terminal = self:getBuiltinTerminal()
    if not terminal then
        UIManager:show(TextViewer:new{
            title = _("KOReader terminal unavailable"),
            text = _([[The built-in KOReader Terminal emulator is not available to this plugin.

Enable “Terminal emulator” under KOReader's built-in plugins, restart KOReader, and try again.

This SSH Client uses KOReader's own terminal emulator. It does not require kterm and does not start an SSH server on the Kindle.]]),
        })
        return
    end

    local client_command = self:buildClientCommand(host, nil, true)
    if not client_command then
        self:showClientMissing()
        return
    end

    -- Add a terminal-focused shortcut keyboard only for sessions opened by this
    -- SSH Client. We temporarily wrap the terminal instance's dialog factory;
    -- the stock KOReader Terminal menu and its keyboard remain untouched.
    local original_generate = terminal.generateInputDialog
    local own_generate = rawget(terminal, "generateInputDialog")
    terminal.generateInputDialog = function(term)
        local dialog = original_generate(term)
        if not dialog or type(dialog.buttons) ~= "table" then
            return dialog
        end

        local function send_key(sequence)
            if not term.is_shell_open or not term.ptmx then return end
            local sent, send_err = pcall(term.transmit, term, sequence)
            if not sent then
                UIManager:show(InfoMessage:new{
                    text = _("Could not send terminal key: ") .. tostring(send_err),
                    timeout = 3,
                })
            end
        end
        local function key(label, sequence)
            return {
                text = label,
                callback = function() send_key(sequence) end,
            }
        end

        -- Shell and configuration punctuation, available without switching
        -- the Kindle's global keyboard layout.
        table.insert(dialog.buttons, {
            key("~", "~"), key("|", "|"), key("\\", "\\"), key("/", "/"),
            key("$", "$"), key("-", "-"), key("_", "_"), key("=", "="),
        })
        table.insert(dialog.buttons, {
            key(":", ":"), key(";", ";"), key("*", "*"), key("&", "&"), key("#", "#"),
            key("@", "@"), key("[", "["), key("]", "]"), key("{", "{"), key("}", "}"),
        })
        -- These are sent to the remote PTY (unlike the built-in up/down
        -- buttons, which scroll the local terminal display).
        table.insert(dialog.buttons, {
            key("Ctrl-D", "\004"), key("Ctrl-Z", "\026"), key("Ctrl-L", "\012"),
            key("Ctrl-U", "\021"), key("← SSH", "\027[D"), key("→ SSH", "\027[C"),
            key("↑ SSH", "\027[A"), key("↓ SSH", "\027[B"),
        })
        return dialog
    end

    -- Start KOReader's own terminal shell, then run SSH inside its PTY. This is
    -- important: SSH needs a genuine local TTY for interactive authentication
    -- and for passing the remote shell's terminal input/output through correctly.
    local ok, err = pcall(function()
        terminal:onTerminalStart(nil)
    end)
    -- Restore the regular terminal dialog factory immediately, even if startup
    -- failed. The custom key rows are already attached to this SSH dialog only.
    terminal.generateInputDialog = own_generate
    if not ok then
        UIManager:show(InfoMessage:new{
            text = _("Could not start KOReader's built-in terminal: ") .. tostring(err),
            timeout = 5,
        })
        return
    end

    -- Let the terminal widget and local shell initialize before typing the SSH
    -- command into its PTY. Terminal:transmit also resumes the emulator refresh loop.
    UIManager:scheduleIn(0.8, function()
        if not terminal.is_shell_open or not terminal.ptmx then
            UIManager:show(TextViewer:new{
                title = _("Could not start terminal session"),
                text = _([[KOReader's terminal emulator could not open a pseudo-terminal.

Check that the built-in Terminal emulator works by itself from Tools → More tools → Terminal emulator. Some customized device builds may not provide /dev/ptmx.]]),
            })
            return
        end
        local sent, send_err = pcall(function()
            terminal:transmit(client_command .. "\r")
        end)
        if not sent then
            UIManager:show(InfoMessage:new{
                text = _("Could not start SSH inside the terminal: ") .. tostring(send_err),
                timeout = 5,
            })
        end
    end)
end


-- Start the SSH Client's own terminal UI: an ANSI screen model with colour
-- rendering and its own PTY, independent of KOReader's Terminal emulator UI.
function SSHClient:openColorTerminal(index)
    local host = self.hosts[index]
    if not host then return end
    local command = self:buildClientCommand(host, nil, true)
    if not command then
        self:showClientMissing()
        return
    end
    local ok, ColorTerminal = pcall(require, "ssh_color_terminal")
    if not ok or not ColorTerminal or not ColorTerminal.open then
        UIManager:show(InfoMessage:new{
            text = _("The custom colour terminal module could not be loaded: ") .. tostring(ColorTerminal),
            timeout = 5,
        })
        return
    end
    local opened, open_err = pcall(ColorTerminal.open, { command = command, host_label = self:hostLabel(host) })
    if not opened then
        UIManager:show(InfoMessage:new{
            text = _("Could not start Color SSH Terminal: ") .. tostring(open_err),
            timeout = 5,
        })
    end
end

function SSHClient:promptRemoteCommand(index)
    local host = self.hosts[index]
    if not host then return end
    local dialog
    dialog = InputDialog:new{
        title = string.format(_("Command to run on %s"), host_target(host)),
        input = "uname -a",
        buttons = {
            {{ text = _("Cancel"), callback = function() UIManager:close(dialog) end }},
            {{ text = _("Run"), callback = function()
                local command = trim(dialog:getInputText())
                UIManager:close(dialog)
                if command == "" then
                    UIManager:show(InfoMessage:new{ text = _("Enter a remote command."), timeout = 2 })
                    return
                end
                self:runRemoteCommand(index, command, _("Remote command output"))
            end }},
        },
    }
    UIManager:show(dialog)
end

function SSHClient:runRemoteCommand(index, remote_command, title)
    local host = self.hosts[index]
    if not host then return end
    local command = self:buildClientCommand(host, remote_command, false)
    if not command then
        self:showClientMissing()
        return
    end

    -- Background the SSH process and poll its output file. This keeps KOReader's
    -- UI responsive if a remote host is slow or unreachable and avoids relying
    -- on UIManager.looper / Turbo async APIs (not available in some noframework
    -- installations).
    local base = os.tmpname()
    if not base or base == "" then
        UIManager:show(InfoMessage:new{ text = _("Could not allocate temporary output files."), timeout = 3 })
        return
    end
    os.remove(base)
    local output_path = base .. ".out"
    local status_path = base .. ".status"
    os.remove(output_path)
    os.remove(status_path)

    local launch = "(" .. command .. "; rc=$?; printf '%s\\n' \"$rc\" > "
        .. shell_quote(status_path) .. ") > " .. shell_quote(output_path) .. " 2>&1 < /dev/null &"
    local exec_ok, exec_err = pcall(os.execute, launch)
    if not exec_ok then
        UIManager:show(InfoMessage:new{ text = _("Could not start SSH command: ") .. tostring(exec_err), timeout = 4 })
        return
    end

    UIManager:show(InfoMessage:new{ text = _("Connecting over SSH…"), timeout = 1.5 })
    local started = os.time()
    local function poll()
        local status_text = read_file(status_path)
        if status_text then
            local output = read_file(output_path) or ""
            local code = tonumber(trim(status_text))
            os.remove(output_path)
            os.remove(status_path)
            os.remove(base)
            if trim(output) == "" then output = _("(No output)") end
            if code ~= 0 then
                output = output .. "\n\n" .. string.format(_("SSH command exit status: %s"), tostring(code or "unknown"))
                if not host.key or trim(host.key) == "" then
                    output = output .. "\n" .. _("Note: command mode cannot answer password prompts. Configure a private key or use an interactive terminal.")
                end
                if not host.trust_first_use then
                    output = output .. "\n" .. _("If this is the first connection, verify the host identity and try the host's first-use trust option, or connect interactively first.")
                end
            end
            UIManager:show(TextViewer:new{ title = title or _("SSH output"), text = output })
            return
        end

        if os.difftime(os.time(), started) > 180 then
            local output = read_file(output_path) or ""
            output = output .. "\n\n" .. _("No exit status received after 3 minutes. The SSH command may still be running; output shown is partial.")
            UIManager:show(TextViewer:new{ title = title or _("SSH output (partial)"), text = output })
            return
        end
        UIManager:scheduleIn(0.5, poll)
    end
    UIManager:scheduleIn(0.5, poll)
end

function SSHClient:showClientMissing()
    local full_dir = DataStorage:getFullDataDir() or "/mnt/us/koreader"
    UIManager:show(TextViewer:new{
        title = _("SSH client executable not found"),
        text = string.format(_([[The plugin needs an SSH client executable such as Dropbear's dbclient.

Checked the standard KOReader locations, including:
%s/dbclient
/mnt/us/koreader/dbclient
/usr/bin/dbclient

If dbclient or ssh is installed elsewhere, choose “SSH client status / executable” and enter its full path. This plugin does not start the Kindle's SSH server.]]), full_dir),
    })
end

function SSHClient:showClientStatus()
    local client = self:findClient()
    local terminal = self:getBuiltinTerminal()
    local path = client or _("Not found")
    local terminal_status = terminal and _("Available (KOReader built-in)")
        or _("Not detected — enable Terminal emulator")
    local text = string.format(_([[SSH client: %s
Built-in terminal: %s

Saved hosts: %d
Settings file: %s

The SSH client connects FROM the Kindle to other machines. The built-in KOReader SSH server is separate.]]),
        path, terminal_status, #self.hosts, self.settings_file)
    local dialog
    dialog = ButtonDialog:new{
        title = string.format(_("SSH client: %s\nTerminal: %s"), path, terminal_status),
        buttons = {
            {{ text = _("Set client executable path"), callback = function()
                UIManager:close(dialog)
                self:promptClientPath()
            end }},
            {{ text = _("Clear custom path"), callback = function()
                UIManager:close(dialog)
                self.client_path_override = nil
                self:saveSettings()
                self:showClientStatus()
            end }},
            {{ text = _("Show details"), callback = function()
                UIManager:close(dialog)
                UIManager:show(TextViewer:new{ title = _("SSH client status"), text = text })
            end }},
            {{ text = _("Back"), callback = function()
                UIManager:close(dialog)
                self:showHosts()
            end }},
        },
    }
    UIManager:show(dialog)
end

function SSHClient:promptClientPath()
    local dialog
    dialog = InputDialog:new{
        title = _("Full path to dbclient or ssh executable"),
        input = self.client_path_override or "/mnt/us/koreader/dbclient",
        buttons = {
            {{ text = _("Cancel"), callback = function() UIManager:close(dialog) end }},
            {{ text = _("Save"), callback = function()
                local path = trim(dialog:getInputText())
                UIManager:close(dialog)
                if path == "" then
                    self.client_path_override = nil
                elseif not is_executable(path) then
                    UIManager:show(InfoMessage:new{ text = _("That path is not an executable file."), timeout = 3 })
                    self:promptClientPath()
                    return
                else
                    self.client_path_override = path
                end
                self:saveSettings()
                self:showClientStatus()
            end }},
        },
    }
    UIManager:show(dialog)
end

function SSHClient:showHelp()
    UIManager:show(TextViewer:new{
        title = _("SSH Client — help"),
        text = _([[This is an SSH CLIENT for connecting from your Kindle to other devices. It is not an SSH server.

1. Add a host: profile name, hostname/IP, remote username, port, and (optionally) private key path.
2. Use “Run remote command” for a one-off command and a scrollable output view.
3. Use “Open Color SSH Terminal (experimental)” for the plugin's own ANSI colour terminal, or “Open built-in KOReader terminal (SSH)” for KOReader's native terminal as a fallback.

Authentication:
• Key-based authentication is recommended.
• Command mode cannot answer an interactive password prompt.
• If first-use host-key verification needs a prompt, connect in an interactive terminal first. As an alternative, you can enable automatic first-use host-key acceptance per host, but only do that when you can independently verify the host identity.
• The plugin stores host details and a key-file path only. It does not copy, generate, or store private-key contents.

Compatibility:
• The plugin looks for KOReader's bundled Dropbear dbclient and common ssh paths.
• If the executable is elsewhere, set its full path from the status menu.
• The custom Color SSH Terminal has its own pseudo-terminal, terminal screen model, ANSI SGR colour support (16, 256-colour and truecolour), cursor addressing, compact docked SSH keyboard, and scrollback viewer. It is an early implementation; uncommon terminal protocols and some full-screen programs may not behave exactly like a desktop xterm. The built-in KOReader terminal remains available as a fallback.
• The built-in-terminal option uses KOReader's own pseudo-terminal and keyboard handling.
• The command runner polls output files and does not use KOReader's asynchronous HTTP / Turbo path, so it does not depend on UIManager.looper.]]),
    })
end

function SSHClient:onCloseWidget()
    if self.settings then self:saveSettings() end
end

return SSHClient
