local _ = require("gettext")
return {
    name = "sshclient",
    fullname = _("SSH Client"),
    description = _([[Connect from KOReader to other devices over SSH, save host profiles, run remote commands, and use a dedicated ANSI colour SSH terminal.]]),
}
