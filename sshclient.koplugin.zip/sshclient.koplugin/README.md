# KOReader SSH Client — custom colour terminal build

**SSH client, not a server.** This plugin connects from the Kindle running KOReader to other devices.

## Install

1. Extract the ZIP.
2. Replace the existing `sshclient.koplugin` folder in your KOReader `plugins` directory (often `/mnt/us/koreader/plugins/`).
3. Restart KOReader.
4. Open **Tools → More tools → SSH Client**.

## Features

- Saved SSH host profiles (hostname/IP, username, port and optional private-key path).
- Remote one-off commands and connection tests.
- **Open Color SSH Terminal (experimental):** the SSH Client's own pseudo-terminal and ANSI screen renderer, with standard 16-color, 256-color and 24-bit SGR color codes; cursor movement, erase commands, scrolling regions, alternate screen, and a bounded scrollback buffer.
- A full-screen terminal view sized to the Kindle display, with more visible terminal rows and no default TextViewer inset.
- A compact SSH-only keyboard docked below the terminal output (not a modal overlay or InputDialog). The collapsed view has a two-row shortcut strip; tap **Keyboard** to expand a QWERTY or symbol layer in the same screen. Letters, numbers, Shift/Ctrl, shell punctuation, Tab, Esc, Ctrl sequences, arrows, Home/End, Page Up/Down, Backspace, Space and Enter send directly to the remote PTY. It never opens KOReader's normal virtual keyboard. The PTY dimensions are adjusted to the visible terminal area when toggling the keyboard.
- The existing **Open built-in KOReader terminal (SSH)** option remains available as a fallback.
- Custom `dbclient`/`ssh` executable path support.

## About the custom terminal

The plugin creates a local pseudo-terminal and executes the configured SSH client inside it. It advertises `TERM=xterm-256color` and renders ANSI SGR foreground/background colours through KOReader's HTML renderer. Closing the terminal now first disables its poll callback, closes the custom keyboard, terminates the SSH process group, reaps the child, and only then removes the terminal view. It is intended to improve the colour output and usability of shell sessions. Terminal emulation is an early implementation, not a complete xterm clone: uncommon control sequences, mouse-driven applications, some alternate-screen behaviour, and particular full-screen TUIs may still behave differently than on a desktop terminal. Use the built-in-terminal option if an application does not render correctly.

## Security

- SSH host-key verification remains enabled by default.
- Use SSH keys when possible; key contents are never stored by this plugin.
- The plugin doesn't open incoming ports or start a server on the Kindle.


## Viewport, full-screen app and refresh update

The custom terminal renders a fixed grid sized to the actual HTML viewport, including when the SSH keyboard opens or closes. It always redraws from the top of the live grid rather than jumping to the last HTML page, and sends the matching row/column dimensions to the SSH PTY so full-screen programs such as `htop` can redraw on `SIGWINCH`. It uses a dedicated 13px code font unaffected by KOReader's global TextViewer font-size preferences. The terminal background and foreground follow KOReader day/night mode. Output polling runs every 50ms, while visible rendering is coalesced to reduce unnecessary redraws. The HTML bitmap cache is invalidated on each content update so incoming SSH output is actually displayed.


## Keyboard-toggle screen preservation

When the docked keyboard changes the viewport height, screen resizing preserves the top-left part of both the primary and alternate terminal grids instead of keeping only the bottom rows. This avoids discarding command output followed by blank rows and prevents full-screen programs from collapsing visually to their last line. The PTY is resized so interactive programs can redraw. Terminal polling uses a 50 ms interval for responsive key/output updates.
